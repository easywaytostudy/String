# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from models import Indeed
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, redirect
from services.test import Test
from django.contrib.auth.models import User
from form import SignupForm
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# Create your views here.

def home(request):
	# Test()
	indeed_data = Indeed.objects.all()
	page = request.GET.get('page', 1)
	paginator = Paginator(indeed_data, 20)
	try:
		data = paginator.page(page)
	except PageNotAnInteger:
		data = paginator.page(1)
	except EmptyPage:
		data = paginator.page(paginator.num_pages)
	args={}
	args['data'] = data
	return render(request, 'index.html', args)


def signup(request):
	if request.method == 'POST':
		form = SignupForm(request.POST)
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('/scrap/login')
	args={}
	args['form'] = SignupForm()
	return render(request, 'signup.html', args)


def login1(request):
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(username=username, password=password)
		if user is not None:
			return render(request, 'index.html')
			# return redirect('home')
		else:
			return HttpResponse("Invalid Login")

	return render(request, 'login.html')


def logout1(request):
	logout(request)
	return redirect('home')

