from __future__ import absolute_import, unicode_literals
from celery import task
# from scrap.models import *
from scrap.services.test import Test
from tqdm import tqdm


@task()
def test():
    Test()
    return "Done!"

