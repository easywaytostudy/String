# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from datetime import date
from django.contrib.auth.models import User


# Create your models here.
class Indeed(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(null=True, max_length=255)
    location = models.CharField(null=True, max_length=255)
    salary = models.CharField(null=True, max_length=255)
    summary = models.CharField(null=True, max_length=255)
    post = models.CharField(null=True, max_length=255)
    created_post = models.DateField(null=True)
    # ad_id = models.CharField(max_length=255, unique=True)

    @property
    def days(self):
        result = date.today()-self.created_post
        if result.days >= 30:
            return "30+"
        else:
            return result.days

    def __unicode__(self):
        return self.title

    class Meta:
        db_table = "indeed"
        verbose_name = "Indeed"
