# from scrap.models import *
from scrap.models import Indeed
import requests
from bs4 import BeautifulSoup
from utils import sleep_scrapper, get_request_headers, scraper_csv_write, URL, POST, CSV_FILE_NAME
import traceback
from datetime import timedelta
from django.utils import timezone


class Test(object):

    def __init__(self):

        self.test_data()

    def test_data(self):

        base_url = URL
        for j in range(0, 1000, 10):
            url = ''

            try:
                if j == 0:
                    url = base_url
                else:
                    url = base_url + str(j)
                print '[IndeedScrapper] :: fetching data from url:', url

                r = requests.get(url, headers=get_request_headers())

                if not r.status_code == 200:
                    print "[IndeedScrapper] :: Failed to get content of url: %s" % url
                    continue

                html_doc = r.content
                soup = BeautifulSoup(html_doc, 'html.parser')

                for div in soup.find_all('div'):

                    if not div.attrs.has_key('class'):
                        continue

                    data = div.attrs['class']
                    if 'row' in data and 'result' in data:
                        self.scrap_result_row(div)

                sleep_scrapper('IndeedScraper')

            except Exception as exp:
                print '[IndeedScraper] :: run() :: Got exception : ' \
                      '%s and fetching data from url: %s' % (exp, url)
                print(traceback.format_exc())


    def scrap_result_row(self, div):
        try:
            # title
            # id = div.find('h2', class_='jobtitle')
            # indeed_id = id.attrs['id']
            # print "[IndeedScrapper] :: indeed_id: %s" % indeed_id

            title = div.find('span', class_='company').text.strip().replace(",", "")
            print "[IndeedScrapper] :: title: %s" % title

            # location
            location = ''
            span = div.find('span', class_='location')
            if span:
                location = span.text.strip().replace(",", "")
            print "[IndeedScrapper] :: location: %s" % location

            # salary
            sal = ''
            span = div.find('span', class_='no-wrap')
            if span:
                sal = span.text.strip().replace(",", "")
            print "[IndeedScrapper] :: salary: %s" % sal

            # summary
            summary = ''
            span = div.find('span', class_='summary')
            if span:
                summary = span.text.strip().replace(",", "")
            print "[IndeedScrapper] :: summary: %s" % summary

            # date
            some_days_ago = ''
            span = div.find('span', class_='date')
            if span:
                date = span.text.strip().split(' ')[0]
                if date == '':
                    days = None
                elif date == "30+":
                    days = int(30)
                else:
                    days = int(date)
                print days
                some_days_ago = timezone.now().date() - timedelta(days)

            print "[IndeedScrapper] :: date: %s" % some_days_ago

            # if Indeed.objects.filter(ad_id=indeed_id).exists():
            #     pass
            # else:
            Indeed.objects.create(title=title, location=location, salary=sal, summary=summary, post=POST, created_post=some_days_ago)

            # fname = 'data_indeed.csv'
            indeed_data = "%s, %s, %s, %s, %s" % (title, location, sal, summary, POST)
            print "[IndeedScrapper] :: scrap_result_row() :: msg    :", indeed_data
            scraper_csv_write(CSV_FILE_NAME, indeed_data)

        except Exception as exp:
            print '[IndeedScrapper] :: scrap_result_row() :: ' \
                  'Got exception: %s' % exp
            print(traceback.format_exc())
