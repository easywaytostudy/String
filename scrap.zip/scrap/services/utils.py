from random import randint
import time

SCRAPPER_SLEEP_MIN = 10  # in seconds
SCRAPPER_SLEEP_MAX = 20  # in seconds
DOMAIL = '.in'
POST = 'python'
LOCATION = 'mohali punjab'
CSV_FILE_NAME = 'data_indeed.csv'
URL ='https://www.indeed.co%s/jobs?q=%s&l=%s&start=' % (DOMAIL, POST, LOCATION)

# URL = "https://www.indeed.co.in/jobs?q=python&l=mohali punjab&start"


#################################################################################
#    it is user agent identification, the browser sends a host of information   #
#    about the device and network that it's on.                                 #
#################################################################################
def get_request_headers():
    agents = ['Mozilla/5.0', 'Safari/537.36', 'Chrome/63.0.3239.132', 'AppleWebKit/537.36', 'Opera/9.80']
    return {'User-Agents': agents[randint(0, len(agents)-1)]}


def get_rand_in_range(min, max):
    return randint(min, max)


def get_scrapper_sleep():
    return get_rand_in_range(SCRAPPER_SLEEP_MIN, SCRAPPER_SLEEP_MAX)


def sleep_scrapper(scrapper_name):
    val = get_scrapper_sleep()
    print "\n\n[%s] :: SLEEPING FOR %d seconds.....\n\n" % (scrapper_name, val)
    time.sleep(val)
    print "\n\n[%s] :: RESUMED \n\n" % scrapper_name


def scraper_csv_write(fname, msg):
    msg = msg.encode("utf-8")

    """
    with open(fname, "a") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(row)
    """

    f = open(fname, "a")
    f.write("%s\n" % msg)
    f.close()
